package br.ifba.sistema_chamados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaChamadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaChamadosApplication.class, args);
	}

}
