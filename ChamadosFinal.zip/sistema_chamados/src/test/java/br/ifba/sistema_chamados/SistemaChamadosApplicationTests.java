package br.ifba.sistema_chamados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaChamadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
